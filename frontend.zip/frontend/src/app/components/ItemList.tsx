"use client";
import { useStore } from '../store';

const ItemList = () => {
  const items = useStore((state) => state.items);
  const deleteItem = useStore((state) => state.deleteItem);
  const updateItem = useStore((state) => state.updateItem);

  return (
    <ul>
      {items.map((item) => (
        <li key={item._id}>
          {item.name} - {item.quantity}
          <button onClick={() => deleteItem(item._id)}>Delete</button>
          <button onClick={() => updateItem(item._id, item.quantity + 1)}>Increase Quantity</button>
        </li>
      ))}
    </ul>
  );
};

export default ItemList;

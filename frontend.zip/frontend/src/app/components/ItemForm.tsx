"use client";
import { useStore } from '../store';
import { useState } from 'react';

const ItemForm = () => {
  const addItem = useStore((state) => state.addItem);
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addItem(name, quantity);
    setName('');
    setQuantity(0);
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Item name"
      />
      <input
        type="number"
        value={quantity}
        onChange={(e) => setQuantity(Number(e.target.value))}
        placeholder="Quantity"
      />
      <button type="submit">Add Item</button>
    </form>
  );
};

export default ItemForm;

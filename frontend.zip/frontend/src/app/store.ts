import create from 'zustand';
import axios from 'axios';

interface Item {
  _id: string;
  name: string;
  quantity: number;
}

interface State {
  items: Item[];
  fetchItems: () => Promise<void>; 
  addItem: (name: string, quantity: number) => Promise<void>;
  updateItem: (id: string, quantity: number) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
}

export const useStore = create<State>((set) => ({
  items: [],
  fetchItems: async () => {
    try {
      const response = await axios.get<Item[]>('http://localhost:4000/api/items');
      set({ items: response.data });
    } catch (error) {
      console.error('Error fetching items:', error);
    }
  },
  addItem: async (name: string, quantity: number) => {
    try {
      const response = await axios.post<Item>('http://localhost:4000/api/items', { name, quantity });
      set((state) => ({ items: [...state.items, response.data] }));
    } catch (error) {
      console.error('Error adding item:', error);
    }
  },
  updateItem: async (id: string, quantity: number) => {
    try {
      const response = await axios.patch<Item>(`http://localhost:4000/api/items/${id}`, { quantity });
      set((state) => ({
        items: state.items.map((item) => (item._id === id ? response.data : item)),
      }));
    } catch (error) {
      console.error('Error updating item:', error);
    }
  },
  deleteItem: async (id: string) => {
    try {
      await axios.delete(`http://localhost:4000/api/items/${id}`);
      set((state) => ({ items: state.items.filter((item) => item._id !== id) }));
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  },
}));
export default useStore;

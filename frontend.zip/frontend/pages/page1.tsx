"use client";
import { useStore } from '../src/app/store';
import { useEffect } from 'react';
import ItemList from '../src/app/components/ItemList';
import ItemForm from '../src/app/components/ItemForm';

export default function Page1() {
  const fetchItems = useStore((state) => state.fetchItems);

  useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  return (
    <div>
      <h1>Page 1</h1>
      <ItemForm />
      <ItemList />
    </div>
  );
}

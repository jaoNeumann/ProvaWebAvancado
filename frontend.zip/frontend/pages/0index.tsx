import { useEffect } from 'react';
import { useStore } from '../src/app/store';
import Link from 'next/link';

const Home = () => {
  const { items, fetchItems, addItem, updateItem, deleteItem } = useStore();

  useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  return (
    <div>
      <h1>Home Page</h1>
      <ul>
        {items.map((item) => (
          <li key={item._id}>
            {item.name} - {item.quantity}
            <button onClick={() => updateItem(item._id, item.quantity + 1)}>+</button>
            <button onClick={() => updateItem(item._id, item.quantity - 1)}>-</button>
            <button onClick={() => deleteItem(item._id)}>Delete</button>
          </li>
        ))}
      </ul>
      <button onClick={() => addItem('New Item', 1)}>Add Item</button>
      <br />
      <Link href="/about">Go to About</Link>
    </div>
  );
};

export default Home;

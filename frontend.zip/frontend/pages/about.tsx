import { useStore } from '../src/app/store';
import Link from 'next/link';

const About = () => {
  const { items } = useStore();

  return (
    <div>
      <h1>About Page</h1>
      <ul>
        {items.map((item) => (
          <li key={item._id}>
            {item.name} - {item.quantity}
          </li>
        ))}
      </ul>
      <br />
      <Link href="/">Go to Home</Link>
    </div>
  );
};

export default About;
